// import React, { Component } from 'react';
// import './App.css';

// class App extends Component {
//   render() {
//     return (
//       <div className="App">
//         <header className="App-header">
//           <h1>Welcome to My React App</h1>
//         </header>

//         <main>
//           <p>This is a simple React application.</p>
//         </main>
//       </div>
//     );
//   }
// }
// export default App;

import React, { Component } from 'react';
class App extends Component {
  render() {
    return (
      <div
        style={{
          textAlign: "center",
          marginTop: "50px"
        }}
      >
        <header
          style={{
            backgroundColor: "lightgreen",
            padding: "20px"
          }}
        >
          <h1 style={{ color: "blue" }}>
            Welcome to My React App
          </h1>
        </header>

        <main>
          <p style={{ color: "red" }}>
            This is a simple React application using Inline CSS.
          </p>
        </main>
      </div>
    );
  }
}

export default App;


//module.css
// import React, { Component } from 'react';
// import styles from './App.module.css';

// class App extends Component {
//   render() {
//     return (
//       <div className={styles.App}>
//         <header className={styles.header}>
//           <h1 className={styles.title}>
//             Welcome to My React App
//           </h1>
//         </header>

//         <main>
//           <p className={styles.text}>
//             This is a simple React application using CSS Module.
//           </p>
//         </main>
//       </div>
//     );
//   }
// }

// export default App;